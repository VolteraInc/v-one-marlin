#include "../../libraries/ADS126X/ADS126X.h"
#include "../VOne.h"
#include "Endstop.h"
#include "ScopedEndstopEnable.h"

//hardware definitions
#define X_MUX_P 3
#define X_MUX_N 2
#define Y_MUX_P 5
#define Y_MUX_N 4
#define Z_MUX_P 7
#define Z_MUX_N 6

#define TRIGGER_THRESHOLD 100
#define NUM_SAMPLES 10

//references to endstops
EndstopMonitor& esMonitor;
const Endstop *xyzFront, *xyzBack, *xyzLeft, *xyzRight;
enum Axis {X, Y, Z};

//local vars
uint32_t _tuneXValue, _tuneYValue, _tuneZValue;
bool _invertX = false, _invertY = false, _invertZ = false;
uint16_t _gain, _filter, _dataRate;
//Axis _channel = X;

//functional prototypes
void configXYZ();
void tuneXYZEndstops();
void tuneXYZEndstop(const Endstop& endstop);
bool isXYZTouch(const Endstop& endstop);
void setChannel(const Endstop& endstop);
//void setChannel(Axis channel);


//set up chip
ADS126X xyzSensor = ADS126X(XYZ_CS_PIN, XYZ_START, ADC_PWDN, ADC_RST, XYZ_DATA_RDY);

void configXYZ() //this must be done after endstops are constructed (e.g. bottom of V-One.cpp)
{
    //load up pointers to endstops
    //esMonitor = vone->stepper.endstopMonitor;
    xyzFront = &vone->endstops.xyPositionerForward;
    xyzBack = &vone->endstops.xyPositionerBack;
    xyzLeft = &vone->endstops.xyPositionerLeft;
    xyzRight = &vone->endstops.xyPositionerRight;

    //tune all the endstops
    tuneXYZEndstops();

    //need someway to make sure that the adc is configured properly (i.e. correct polarity, correct gain, not saturated)

    return;
}

void tuneXYZEndstops()
{
    tuneXYZEndstop(*xyzFront);
    tuneXYZEndstop(*xyzBack);
    tuneXYZEndstop(*xyzLeft);
    tuneXYZEndstop(*xyzRight);
    /*_channel = X;
    setChannel(_channel);
    _tuneXValue = 0;
    for(int i = 0; i < NUM_SAMPLES; i++)
    {
        _tuneXValue =+ xyzSensor.getADCData()/10;
    }

    _channel = Y;
    setChannel(_channel);
    _tuneYValue = 0;
    for(int i = 0; i < NUM_SAMPLES; i++)
    {
        _tuneYValue =+ xyzSensor.getADCData()/10;
    }

    _channel = Y;
    setChannel(_channel);
    _tuneYValue = 0;
    for(int i = 0; i < NUM_SAMPLES; i++)
    {
        _tuneYValue =+ xyzSensor.getADCData()/10;
    }*/
}

void tuneXYZEndstop(const Endstop& endstop)
{
    if(endstop.axis == X_AXIS)
    {
        //_channel = X;
        setChannel(endstop);
        _tuneXValue = 0;
        for(int i = 0; i < NUM_SAMPLES; i++)
        {
            _tuneXValue =+ xyzSensor.getADCData()/10;
        }
        
        //implement method for flipping polarity?
    }
    else if (endstop.axis == Y_AXIS)
    {
        //_channel = Y;
        setChannel(endstop);
        _tuneYValue = 0;
        for(int i = 0; i < NUM_SAMPLES; i++)
        {
            _tuneYValue =+ xyzSensor.getADCData()/10;
        }

        //implement method for flipping polarity?
    }
    else //Z_axis
    {
        //_channel = Z;
        setChannel(endstop);
        _tuneZValue = 0;
        for(int i = 0; i < NUM_SAMPLES; i++)
        {
            _tuneYValue =+ xyzSensor.getADCData()/10;
        }

        //implement method for flipping polarity?
    }
}

bool isXYZTouch(const Endstop& endstop) //currently implemented to just see if something is triggered in this axis, reducing computation time
{
    //const Endstop *es = &endstop;
    uint32_t analogReading;
    setChannel(endstop);
    analogReading = xyzSensor.getADCData();
    
    if(endstop.axis == X_AXIS)
    {
        return (abs(analogReading - _tuneXValue) > TRIGGER_THRESHOLD ) ? true : false;
    }
    else if (endstop.axis == Y_AXIS)
    {
        return (abs(analogReading - _tuneYValue) > TRIGGER_THRESHOLD ) ? true : false;
    }
    else if (endstop.axis == Z_AXIS)//Z_axis
    {
        return (abs(analogReading - _tuneZValue) > TRIGGER_THRESHOLD ) ? true : false;
    }
    else
    {
        return true; //if we cannot find anything, pass true as this will prevent damage in the machine, how to throw exception from here?
    }

}

void setChannel(const Endstop& endstop)
{
    if(endstop.axis == X_AXIS)
    {
        if(_invertX)
        {
            xyzSensor.setMux(X_MUX_N, X_MUX_P);
        }
        else
        {
            xyzSensor.setMux(X_MUX_P, X_MUX_N);
        }
    }
    else if (endstop.axis == Y_AXIS)
    {
        if(_invertY)
        {
            xyzSensor.setMux(Y_MUX_N, Y_MUX_P);
        }
        else
        {
            xyzSensor.setMux(Y_MUX_P, Y_MUX_N);
        }
    }
    else //Z_axis
    {
        if(_invertZ)
        {
            xyzSensor.setMux(Z_MUX_N, Z_MUX_P);
        }
        else
        {
            xyzSensor.setMux(Z_MUX_P, Z_MUX_N);
        }
    }
}

/*void setChannel(Axis channel)
{
    if(channel == X)
    {
        if(_invertX)
        {
            xyzSensor.setMux(X_MUX_N, X_MUX_P);
        }
        else
        {
            xyzSensor.setMux(X_MUX_P, X_MUX_N);
        }
    }
    else if (channel == Y)
    {
        if(_invertY)
        {
            xyzSensor.setMux(Y_MUX_N, Y_MUX_P);
        }
        else
        {
            xyzSensor.setMux(Y_MUX_P, Y_MUX_N);
        }
    }
    else //Z_axis
    {
        if(_invertZ)
        {
            xyzSensor.setMux(Z_MUX_N, Z_MUX_P);
        }
        else
        {
            xyzSensor.setMux(Z_MUX_P, Z_MUX_N);
        }
    }
}*/